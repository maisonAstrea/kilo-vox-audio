# Master Vox

Studio de mastering à servir depuis ton site. Le moteur et l’export tournent dans le navigateur. Les fichiers audio restent sur l’appareil du visiteur.

Copie `index.html`, `style.css`, `quantum.css`, `quantum.js`, `app.js`, `dsp.js`, `backdrop.js` et `cosmos.jpg` dans un dossier public de ton hébergement, par exemple `/mastering/`. Fais pointer un lien de ton site vers cette adresse. Pour intégrer l’outil dans une page du même site, tu peux aussi utiliser un iframe avec `src="/mastering/"`, `title="Master Vox"` et une hauteur adaptée à ta page. Si ton hébergeur applique une politique CSP, autorise les scripts et les workers de la même origine.

Pour un aperçu local, sers le dossier par HTTP avec `python3 -m http.server 8765`, puis ouvre `http://localhost:8765`.

L’import accepte les formats audio décodés par le navigateur, en mono ou stéréo, jusqu’à 10 minutes et 160 Mo. Le navigateur décode à 48 kHz et l’export produit un WAV PCM 24 bits à cette fréquence. Les commandes A/B et Mono agissent sur l’écoute. L’export utilise le master traité avec les derniers réglages appliqués. Le plafond concerne les crêtes d’échantillon en dBFS.


## Mastering automatique

À l’import, le moteur mesure le niveau sonore pondéré, les crêtes, la dynamique, les graves, les aigus et la largeur stéréo. Il propose des corrections modérées en fonction du morceau et vise un niveau de référence d’environ −14 LUFS lorsque la réserve de crête le permet. C’est un moteur d’analyse du signal à règles, exécuté dans le navigateur. Pour modifier ses choix, ouvre **Modifier les réglages**, puis clique sur **Appliquer**. **Refaire le mastering auto** rétablit les réglages calculés pour le fichier chargé.

## Interface Quantum

Ouvre **Modifier les réglages** et choisis l’un des quatre univers. Fais glisser les points énergétiques verticalement ou utilise les flèches du clavier. Maj avec une flèche augmente le pas. Les champs numériques donnent accès aux 13 paramètres. Clique sur **Appliquer** dans la console pour recalculer le master. Le rendu visuel utilise les échantillons du signal écouté et réagit aux réglages pendant leur édition.

Le **Mode léger** simplifie les scènes et les affiche sans animation continue. Il est proposé par défaut sur petit écran et quand le système demande une réduction des mouvements. Les champs restent disponibles si le canevas ne peut pas être affiché. Les scènes en perspective utilisent Canvas 2D sans bibliothèque supplémentaire.
