'use strict';

const element = id => document.getElementById(id);
const ui = Object.fromEntries(['preset','auto','file','track-name','track-info','wave','wave-empty','seek','play',
  'compare','mono','time','controls','peak','reduction','render','export','status']
  .map(id => [id, element(id)]));
const groups = [
  ['Entrée et égalisation', [
    ['input','Entrée',-24,24,'dB'], ['low','Graves',-9,9,'dB'],
    ['mid','Médiums',-9,9,'dB'], ['high','Aigus',-9,9,'dB']
  ]],
  ['Compresseur', [
    ['threshold','Seuil',-40,0,'dB'], ['ratio','Ratio',1,8,':1'],
    ['attack','Attaque',1,100,'ms'], ['release','Relâchement',20,500,'ms']
  ]],
  ['Saturation et stéréo', [
    ['drive','Saturation',0,100,'%'], ['width','Largeur',0,180,'%'],
    ['output','Sortie',-24,24,'dB']
  ]],
  ['Limiteur', [
    ['ceiling','Plafond',-12,0,'dBFS'], ['limitRelease','Relâchement',20,500,'ms']
  ]]
];
const presets = [
  [0,0,0,0,0,2,25,150,0,100,0,-1,90],
  [0,1.5,-.7,.5,-13,2,33,120,12,105,1.5,-1,100],
  [0,-.5,.4,1.4,-11,1.5,24,150,4,113,1,-1,90],
  [0,.4,-.4,.3,-18,2,20,180,6,100,2,-1,120]
];
const sliders = [];
const consolePanel = document.querySelector('.console');
const playbackPanel = document.querySelector('.studio');
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
let context, monitoring, analyzer, original, processed, source, activeWorker;
let generation = 0;
let revision = 0;
let renderedRevision = -1;
let playingSince = 0;
let offset = 0;
let comparing = false;
let automaticSettings;
let wavePeaks = [];
let filename = '';
let busy = false;
let analyzing = false;

for (const [title, fields] of groups) {
  const fieldset = document.createElement('fieldset');
  const legend = document.createElement('legend');
  legend.textContent = title;
  const row = document.createElement('div');
  row.className = 'quantum-values';
  fieldset.append(legend, row);
  for (const [key, name, min, max, unit] of fields) {
    const label = document.createElement('label');
    const nameSpan = document.createElement('span');
    const slider = document.createElement('input');
    const suffix = document.createElement('span');
    label.className = 'quantum-value';
    nameSpan.textContent = name;
    suffix.textContent = unit;
    suffix.id = key + '-unit';
    slider.setAttribute('aria-label', name);
    slider.setAttribute('aria-describedby', suffix.id);
    Object.assign(slider, { type:'number', inputMode:'decimal', min, max, step:.1, id:key });
    let numericValue = min;
    const update = () => { numericValue = slider.valueAsNumber; quantum.invalidate(); };
    const edit = () => {
      const next = slider.valueAsNumber;
      if (!Number.isFinite(next) || next < min || next > max) return;
      update();
      ui.preset.value = '';
      settingsChanged();
    };
    slider.addEventListener('input', edit);
    slider.addEventListener('change', () => {
      const next = slider.valueAsNumber;
      slider.value = Number.isFinite(next) ? Math.min(max, Math.max(min, next)).toFixed(1) : numericValue;
      edit();
    });
    sliders.push({ key, name, unit, slider, update, value: () => numericValue });
    label.append(nameSpan, slider, suffix);
    row.append(label);
  }
  ui.controls.append(fieldset);
}

const quantum = createQuantumInterface({
  controls: sliders,
  panels: [...ui.controls.children],
  readAudio: () => source ? analyzer : null
});

function setPreset(index) {
  sliders.forEach(({ slider, update }, i) => {
    slider.value = presets[index][i];
    update();
  });
}
setPreset(0);
ui.preset.addEventListener('change', () => {
  if (ui.preset.value === 'auto') {
    if (original) render(true);
    return;
  }
  setPreset(Number(ui.preset.value));
  settingsChanged();
});

function settingsChanged() {
  revision++;
  refreshButtons();
  if (original && !busy) ui.status.textContent = 'Clique sur Appliquer pour écouter les nouveaux réglages.';
}

function refreshButtons() {
  const fresh = processed && revision === renderedRevision;
  consolePanel.dataset.phase = busy ? 'busy' : fresh ? 'ready' : 'idle';
  ui.preset.disabled = busy;
  sliders.forEach(({slider}) => { slider.disabled = analyzing; });
  ui.auto.disabled = !original || busy;
  ui.render.disabled = !original || busy || !!fresh;
  ui.export.disabled = busy || !fresh;
  quantum.invalidate();
  ui.play.disabled = !original;
  ui.compare.disabled = !processed;
  ui.seek.disabled = !original;
}

function formatTime(seconds) {
  const n = Math.floor(seconds);
  return Math.floor(n / 60) + ':' + String(n % 60).padStart(2, '0');
}

function readPosition() {
  return source ? Math.min(original.duration, offset + context.currentTime - playingSince) : offset;
}

function displayPosition(position) {
  ui.seek.value = position;
  ui.time.textContent = formatTime(position) + ' / ' + formatTime(original?.duration || 0);
}

function measureWave(buffer) {
  const channel = buffer.getChannelData(0);
  return Array.from({ length: 400 }, (_, i) => {
    const start = Math.floor(i * channel.length / 400);
    const end = Math.min(channel.length, Math.max(start + 1, Math.floor((i + 1) * channel.length / 400)));
    let peak = 0;
    for (let index = start; index < end; index++) peak = Math.max(peak, Math.abs(channel[index]));
    return peak;
  });
}

function drawWave() {
  const canvas = ui.wave;
  const ratio = Math.min(2, window.devicePixelRatio || 1);
  const width = Math.round(canvas.clientWidth * ratio);
  const height = Math.round(canvas.clientHeight * ratio);
  if (width < 1 || height < 1) return;
  if (canvas.width !== width) canvas.width = width;
  if (canvas.height !== height) canvas.height = height;
  const g = canvas.getContext('2d');
  g.clearRect(0, 0, width, height);
  ui['wave-empty'].hidden = Boolean(original);
  g.fillStyle = '#486883';
  g.fillRect(0, height / 2, width, ratio);
  const stride = width / wavePeaks.length;
  const played = original ? readPosition() / original.duration : 0;
  const waveform = g.createLinearGradient(0, 0, 0, height);
  waveform.addColorStop(0, '#ffdb9d');
  waveform.addColorStop(.5, '#b58cff');
  waveform.addColorStop(1, '#ffd18b');
  wavePeaks.forEach((peak, i) => {
    const distance = Math.abs(i - wavePeaks.length * played);
    const nearCursor = source && !reducedMotion.matches && distance < 10;
    const scale = nearCursor ? 1 + .25 * (1 - distance / 10) : 1;
    const bar = Math.max(ratio, Math.min(1, peak * scale) * height * .88);
    g.fillStyle = i < wavePeaks.length * played ? '#fff2d5' : waveform;
    g.fillRect(i * stride, (height - bar) / 2, Math.max(1, stride - ratio), bar);
  });
  if (original && played > 0) {
    g.fillStyle = '#fff2d5';
    g.shadowColor = '#ffbb68';
    g.shadowBlur = reducedMotion.matches ? 0 : 9 * ratio;
    g.fillRect(Math.min(width - ratio, played * width), 0, ratio, height);
    g.shadowBlur = 0;
  }
}
new ResizeObserver(drawWave).observe(ui.wave);

function newContext() {
  context = new AudioContext({ sampleRate: 48000 });
  monitoring = context.createGain();
  monitoring.channelCountMode = 'explicit';
  monitoring.channelCount = ui.mono.checked ? 1 : 2;
  monitoring.connect(context.destination);
  analyzer = context.createAnalyser();
  analyzer.fftSize = 512;
  analyzer.smoothingTimeConstant = .66;
  monitoring.connect(analyzer);
}
ui.mono.addEventListener('change', () => {
  if (monitoring) monitoring.channelCount = ui.mono.checked ? 1 : 2;
});

function stop() {
  if (source) {
    offset = readPosition();
    source.onended = null;
    source.stop();
    source.disconnect();
    source = null;
  }
  playbackPanel.dataset.playing = 'false';
  ui.play.textContent = 'Écouter';
  drawWave();
}

function start(position) {
  const node = context.createBufferSource();
  node.buffer = comparing ? original : (processed || original);
  node.connect(monitoring);
  offset = position >= original.duration ? 0 : position;
  playingSince = context.currentTime;
  node.start(0, offset);
  source = node;
  playbackPanel.dataset.playing = 'true';
  ui.play.textContent = 'Pause';
  node.onended = () => {
    if (source !== node) return;
    node.disconnect();
    source = null;
    playbackPanel.dataset.playing = 'false';
    offset = 0;
    ui.play.textContent = 'Écouter';
    displayPosition(0);
    drawWave();
  };
  requestAnimationFrame(function tick() {
    if (source !== node) return;
    displayPosition(readPosition());
    drawWave();
    requestAnimationFrame(tick);
  });
}
ui.play.addEventListener('click', async () => {
  if (source) {
    stop();
    return;
  }
  const track = original;
  try {
    await context.resume();
    if (track === original && !source) start(offset);
  } catch {
    ui.status.textContent = 'Le navigateur ne peut pas démarrer la lecture.';
  }
});
ui.seek.addEventListener('input', () => {
  const wasPlaying = !!source;
  stop();
  offset = Number(ui.seek.value);
  if (wasPlaying) start(offset);
  displayPosition(readPosition());
  drawWave();
});
ui.compare.addEventListener('click', () => {
  const wasPlaying = !!source;
  stop();
  comparing = !comparing;
  ui.compare.setAttribute('aria-pressed', String(comparing));
  wavePeaks = measureWave(comparing ? original : processed);
  if (wasPlaying) start(offset);
  drawWave();
});

function workerJob(task, buffer, parameters) {
  return new Promise((resolve, reject) => {
    const worker = new Worker('dsp.js');
    const finish = callback => {
      worker.terminate();
      if (activeWorker?.worker === worker) activeWorker = null;
      callback();
    };
    activeWorker = { worker, cancel: () => finish(() => reject(new Error('Annulé'))) };
    worker.onmessage = ({ data }) => finish(() => data.error ? reject(new Error(data.error)) : resolve(data));
    worker.onerror = () => finish(() => reject(new Error('Le moteur audio ne répond pas.')));
    try {
      const channels = Array.from({length:buffer.numberOfChannels}, (_, i) => buffer.getChannelData(i).slice());
      worker.postMessage({ task, channels, rate:buffer.sampleRate, parameters }, channels.map(channel => channel.buffer));
    } catch (error) {
      finish(() => reject(error));
    }
  });
}

ui.file.addEventListener('change', async () => {
  const file = ui.file.files[0];
  if (!file) return;
  ui.file.value = '';
  const id = ++generation;
  activeWorker?.cancel();
  stop();
  offset = 0;
  busy = analyzing = true;
  original = processed = automaticSettings = null;
  ui.preset.value = 'auto';
  comparing = false;
  ui.compare.setAttribute('aria-pressed', 'false');
  renderedRevision = -1;
  ui.peak.textContent = ui.reduction.textContent = '—';
  wavePeaks = [];
  drawWave();
  displayPosition(0);
  refreshButtons();
  ui['track-name'].textContent = file.name;
  ui['track-info'].textContent = 'Décodage audio…';
  ui.status.textContent = 'Ouverture du fichier…';
  try {
    if (file.size > 160 * 1024 ** 2) throw new Error('Choisis un fichier de 160 Mo maximum.');
    if (!context) newContext();
    const buffer = await context.decodeAudioData(await file.arrayBuffer());
    if (id !== generation) return;
    if (buffer.numberOfChannels > 2 || buffer.duration > 600) {
      throw new Error('Choisis un fichier mono ou stéréo de 10 minutes maximum.');
    }
    original = buffer;
    filename = file.name.replace(/\.[^.]+$/, '');
    wavePeaks = measureWave(buffer);
    ui.seek.max = buffer.duration;
    ui['track-info'].textContent = formatTime(buffer.duration) + ' · ' + (buffer.numberOfChannels === 2 ? 'Stéréo' : 'Mono') + ' · 48 kHz';
    displayPosition(0);
    drawWave();
    await render(true);
  } catch (error) {
    if (id !== generation) return;
    ui['track-info'].textContent = 'Fichier illisible ou format audio non pris en charge.';
    ui.status.textContent = error.message;
    busy = analyzing = false;
    refreshButtons();
  }
});

async function render(automatic = false) {
  const id = generation;
  const settingsRevision = revision;
  busy = true;
  analyzing = automatic;
  refreshButtons();
  ui.status.textContent = automatic ? 'Analyse du mix et mastering automatique…' : 'Traitement du mix…';
  try {
    const settings = Object.fromEntries(sliders.map(({key, value}) => [key, value()]));
    const result = await workerJob(automatic ? 'auto' : 'master', original, automatic ? automaticSettings : settings);
    if (id !== generation) return;
    if (automatic) {
      automaticSettings = result.parameters;
      if (settingsRevision === revision) {
        sliders.forEach(({ key, slider, update }) => {
          slider.value = automaticSettings[key];
          update();
        });
        ui.preset.value = 'auto';
      }
    }
    const next = context.createBuffer(result.channels.length, original.length, original.sampleRate);
    result.channels.forEach((channel, index) => next.copyToChannel(channel, index));
    const wasPlaying = !!source;
    stop();
    processed = next;
    renderedRevision = settingsRevision;
    wavePeaks = measureWave(comparing ? original : processed);
    if (wasPlaying) start(offset);
    drawWave();
    ui.peak.textContent = result.meters.peakDb.toFixed(1) + ' dBFS';
    ui.reduction.textContent = result.meters.reductionDb.toFixed(1) + ' dB';
    ui.status.textContent = settingsRevision === revision ? (automatic ? 'Mastering automatique terminé. Écoute ou exporte ton master.' : 'Master prêt à écouter et à exporter.')
      : 'Les réglages ont changé. Clique sur Appliquer pour les prendre en compte.';
  } catch (error) {
    if (id === generation) ui.status.textContent = 'Rendu interrompu. ' + error.message;
  } finally {
    if (id === generation) {
      busy = analyzing = false;
      refreshButtons();
    }
  }
}

ui.render.addEventListener('click', () => render());
ui.auto.addEventListener('click', () => render(true));
ui.export.addEventListener('click', async () => {
  const id = generation;
  busy = true;
  refreshButtons();
  ui.status.textContent = 'Préparation du WAV 24 bits…';
  try {
    const { wav } = await workerJob('export', processed);
    if (id !== generation) return;
    const url = URL.createObjectURL(new Blob([wav], { type:'audio/wav' }));
    const download = document.createElement('a');
    download.href = url;
    download.download = filename + '-master-vox.wav';
    document.body.append(download);
    download.click();
    download.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    ui.status.textContent = 'WAV 24 bits exporté à 48 kHz.';
  } catch (error) {
    if (id === generation) ui.status.textContent = 'Export interrompu. ' + error.message;
  } finally {
    if (id === generation) {
      busy = false;
      refreshButtons();
    }
  }
});

const advancedPanel = document.querySelector('.advanced');
advancedPanel.open = matchMedia('(min-width: 1051px)').matches;
document.querySelectorAll('[data-control]').forEach(button => {
  button.addEventListener('click', () => {
    advancedPanel.open = true;
    quantum.selectControl(button.dataset.control);
    const slider = element(button.dataset.control);
    slider.closest('fieldset').scrollIntoView({ block: 'nearest' });
    if (!slider.disabled) slider.focus({ preventScroll: true });
  });
});
